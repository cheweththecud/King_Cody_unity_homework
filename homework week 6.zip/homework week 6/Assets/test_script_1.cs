﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test_script_1 : MonoBehaviour {

    private Rigidbody rb;
    public float parameter2 = 10;
        // The private line is declaring a variable.  the public line is also declaring a variable but it is set so that it can be altered from the unity window.

	// Use this for initialization
	void Start () {
        print("Never name your script something this stupid, ever!");
        rb = GetComponent<Rigidbody>();
            // This line above is grabbing the rigid body data from the object and putting it into the variable rb.
	}
	
	// Update is called once per frame
	void Update () {
        rb.AddRelativeForce(Vector3.up * parameter2 * Input.GetAxis("Vertical"));
            // This line above is applying a force to the object's rigid body that makes it roll one way when you press the  'w' key.

        rb.AddTorque(Vector3.left * parameter2 * Input.GetAxis("Vertical"));
            // This line above is also applying a force but it is when you press the 's' key.
	}
}
