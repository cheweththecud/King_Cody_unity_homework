﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript2 : MonoBehaviour {
    private Rigidbody rb;
    public float parameter1;
    private Renderer rend;
	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
        rend = GetComponent<Renderer>();
	}
	
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Color color = Random.ColorHSV();
            rend.material.SetColor("_Color", color);
            
        }
    }   // This function causes the object to change to a random color whenever you press the fire button which is the left mouse button.

	void OnCollisionEnter(Collision collision)
    {
        rb.AddForce(Vector3.up * parameter1);
    }   // Causes the object to bounce up when it collides with something although the forced needs to be turned way up to notice the effect.
}
