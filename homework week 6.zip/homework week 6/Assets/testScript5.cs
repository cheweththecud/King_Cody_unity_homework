﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript5 : MonoBehaviour {
    public float parameter1 = 0.1f;
    public float parameter2 = 0.1f;
    public float parameter3 = 10;
    public float parameter4 = -10;
    private bool parameter5 = true;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(parameter1 > parameter3)
        {
            parameter5 = false;
        }   // This if determines parameter 5

        if (parameter5)
        {
            parameter1 += parameter2;
            RenderSettings.skybox.SetFloat("_Exposure", parameter1);
        } else
        {
            parameter1 -= parameter2;
            RenderSettings.skybox.SetFloat("_Exposure", parameter1);
        }   // This if else statement saise that if parameter five is true then raise the skybox exposure.  And if it is false lower the skybox exposure.  the function is set up so that it alternates between true and false.

        if(parameter1 < parameter4)
        {
            parameter5 = true;
        }   // this if also determines parameter 5

    }
}
