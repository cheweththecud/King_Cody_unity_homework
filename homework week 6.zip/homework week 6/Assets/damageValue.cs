﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damageValue : MonoBehaviour {

    public float damageAmount = 10;

    public float getDamage()
    {
        return damageAmount;
    }
}
