﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class printAfterSeconds : MonoBehaviour {

    // In this example we show how to invoke a coroutine and 
    // continue executing the function in parallel.

    private IEnumerator coroutine;

    void Start()
    {
        // - After 0 seconds, prints "Starting 0.0"
        // - After 0 seconds, prints "Before WaitAndPrint Finishes 0.0"
        // - After 2 seconds, prints "WaitAndPrint 2.0"
        print("Starting " + Time.time);

        // Start function WaitAndPrint as a coroutine.

        coroutine = WaitAndPrint(2.0f);
        StartCoroutine(coroutine);

        print("Before WaitAndPrint Finishes " + Time.time);
    }

    // every 2 seconds perform the print()
    private IEnumerator WaitAndPrint(float waitTime)
    {
        //this is in a while loop, while true means it will work forever and ever as true can never evaluate to false
        while (true)
        {
            yield return new WaitForSeconds(waitTime);
            print("WaitAndPrint " + Time.time);
        }
        //rather than run in a while loop, this is a decent candidate for recursion. Execute your code, then call the StartCoroutine(WaitAndPrint(2.0f)) function again inside here
    }
}
