﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript4 : MonoBehaviour {

    public float life = 100;

	// Use this for initialization
	void Start () {
		
	}
	
	void OnCollisionEnter(Collision collision)
    {
        print(collision.collider.name);
        if(collision.collider.name != "Terrain")    // as long as the collision is not with the terrain run the script below.
        {
            life -= collision.collider.GetComponent<damageValue>().getDamage(); // The object loses life each time it detects a collision.
        }
        if(life < 0)
        {
            Destroy(gameObject);
        }   // when its health drops to zero destroy the object.
    }
}
