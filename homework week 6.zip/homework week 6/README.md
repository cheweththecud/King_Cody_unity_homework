# Test Unity Project

This project exists to show the students of DTC 338 Engines and Platforms what a new, empty Unity3D project should look like for their first assignment.

Course Website: http://dtc-wsuv.org/wp/dtc338-engines/
